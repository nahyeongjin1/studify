package com.example.studify.data.local.db

enum class CategoryType(val label: String) {
    Major("전공"),
    General("교양")
}
